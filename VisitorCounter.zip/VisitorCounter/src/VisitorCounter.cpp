/*
		VisitorCounter @ Hujifa Rafi 8 Aug 2018
		www.facebook.com/hujifa.rafi
		This library is free to use. 
		Author will not be responsible for any damage of your device.
		
*/

#include <VisitorCounter.h>


VisitorCounter::VisitorCounter(byte _sensor_A , byte _sensor_B){
	sensor_A = _sensor_A;
	sensor_B = _sensor_B;
}

void VisitorCounter::run(){
  look_at_the_sensors();
  check_if_A_is_triggered();
  check_if_B_is_triggered();
  compare_trigger_priority();
  update_sensor_data();
}

void VisitorCounter::look_at_the_sensors(){
  curr_state_A = digitalRead(sensor_A);
  curr_state_B = digitalRead(sensor_B);
}
void VisitorCounter::check_if_A_is_triggered(){
   if ( curr_state_A == HIGH ){
     curr_millis_A = millis();
      if ( curr_millis_A - prev_millis_A > debounce ){
         on_triggered_A();
      }
   }
}
void VisitorCounter::check_if_B_is_triggered(){
  if ( curr_state_B == HIGH ){
    curr_millis_B = millis();
      if ( curr_millis_B - prev_millis_B > debounce ){
        on_triggered_B();
       }
   }
}

void VisitorCounter::on_triggered_A(){ 
  if ( trigger_B_cnt == 0 ){
    trigger_A_cnt = 2;
  }
  else {
    trigger_A_cnt = 1;
  }
}

void VisitorCounter::on_triggered_B(){
  if ( trigger_A_cnt == 0 ){
    trigger_B_cnt = 2;
  }
  else{
    trigger_B_cnt = 1;
  }
}

void VisitorCounter::compare_trigger_priority(){
  
  if ( trigger_A_cnt != 0  && trigger_B_cnt != 0 ){
    if ( trigger_A_cnt > trigger_B_cnt ){
      person++;
    }
    else if ( trigger_B_cnt > trigger_A_cnt ){
      if ( person > 0 ){
        person--;
      }
    }
    trigger_A_cnt = 0;
    trigger_B_cnt = 0;
  }
}

void VisitorCounter::update_sensor_data(){
	
  prev_millis_A = curr_millis_A;
  prev_millis_B = curr_millis_B;
}

int VisitorCounter::getPerson(){
	return person;
}