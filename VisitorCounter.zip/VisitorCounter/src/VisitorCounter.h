/*
		VisitorCounter @ Hujifa Rafi 8 Aug 2018
		www.facebook.com/hujifa.rafi
		This library is free to use.
		Author will not be responsible for any damage of your device.
		
*/

#ifndef VisitorCounter_H
#define VisitorCounter_H

#include <Arduino.h>



#define debounce 50

class VisitorCounter {
	
	public:
	
	VisitorCounter(byte _sensor_A , byte _sensor_B);
	void run();
	int getPerson();
	
	private:
	
	void look_at_the_sensors();
	void check_if_A_is_triggered();
	void check_if_B_is_triggered();
	void on_triggered_A();
	void on_triggered_B();
	void compare_trigger_priority();
	void update_sensor_data();
	
	byte sensor_A = 0;
	byte sensor_B = 0;
	
	byte curr_state_A = 0;
	byte curr_state_B = 0;
	
	
	byte trigger_A_cnt = 0;
	byte trigger_B_cnt = 0;
	
	unsigned long curr_millis_A = 0;
	unsigned long curr_millis_B = 0;
	
	unsigned long prev_millis_A = 0;
	unsigned long prev_millis_B = 0;
	
	int person  = 0;
};

#endif